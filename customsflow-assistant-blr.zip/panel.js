const byId = id => document.getElementById(id);
const element = (tag, text, className) => {
  const node = document.createElement(tag);
  node.textContent = text;
  if (className) node.className = className;
  return node;
};

let windowId, candidate, selectedId;
let folded = new Set();

function documentGroup(doc, index) {
  const group = document.createElement('details');
  group.open = !folded.has(index);
  group.append(element('summary', doc.title));
  group.addEventListener('toggle', () => {
    if (!group.isConnected) return;
    if (group.open) folded.delete(index);
    else folded.add(index);
  });
  if (!doc.fields.length) group.append(element('p', 'Aucune valeur vérifiée pour cette pièce.'));
  for (const { label, value } of doc.fields) {
    const row = document.createElement('div');
    row.className = 'field';
    row.append(element('div', label, 'field-label'));
    const line = document.createElement('div');
    line.className = 'field-value';
    const copy = element('button', 'Copier');
    copy.type = 'button';
    copy.setAttribute('aria-label', 'Copier · ' + label);
    copy.onclick = async () => {
      try {
        await navigator.clipboard.writeText(value);
        if (!copy.isConnected) return;
        copy.textContent = 'Copié ✓';
        byId('feedback').textContent = label + ' copié.';
        setTimeout(() => { copy.textContent = 'Copier'; }, 1500);
      } catch {
        byId('feedback').textContent = 'Sélectionnez la valeur et copiez-la avec le raccourci du clavier.';
      }
    };
    line.append(element('span', value), copy);
    row.append(line);
    group.append(row);
  }
  return group;
}

function render(state = {}) {
  const dossier = state.pinned?.dossier;
  candidate = state.candidate;
  byId('empty').hidden = Boolean(candidate || dossier);
  byId('candidate').hidden = !candidate;
  byId('selected').hidden = !dossier;
  byId('feedback').textContent = '';
  if (candidate) {
    const pending = candidate.dossier;
    const label = [pending.id, pending.vehicle, pending.buyer];
    if (pending.id === dossier?.id && candidate.origin !== state.pinned.origin) {
      label.push(candidate.origin.startsWith('https:') ? 'Démo en ligne' : 'Maquette locale');
    }
    byId('candidate-label').textContent = label.join(' · ');
    byId('choose').textContent = pending.status === 'new' ? 'Prendre en charge ce dossier' : 'Utiliser ce dossier';
  }
  const selection = dossier && state.pinned.origin + '/' + dossier.id;
  if (selectedId !== selection) folded = new Set();
  selectedId = selection;
  byId('case-id').textContent = dossier?.id || '';
  byId('vehicle').textContent = dossier?.vehicle || '';
  byId('buyer').textContent = dossier?.buyer || '';
  const groups = dossier?.documents.map(documentGroup) || [];
  if (dossier && !groups.length) groups.push(element('p', 'Aucune pièce avec des valeurs disponibles.'));
  byId('documents').replaceChildren(...groups);
}

byId('choose').onclick = async event => {
  if (!candidate) return;
  const button = event.currentTarget;
  button.disabled = true;
  try {
    const reply = await chrome.runtime.sendMessage({
      type: 'choose', windowId, id: candidate.dossier.id, origin: candidate.origin, take: candidate.dossier.status === 'new'
    });
    if (!reply?.ok) throw new Error();
  } catch {
    byId('feedback').textContent = 'Rouvrez le dossier dans CustomsFlow puis réessayez.';
  } finally {
    button.disabled = false;
  }
};

async function start() {
  windowId = (await chrome.windows.getCurrent()).id;
  const key = 'window-' + windowId;
  let changed = false;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && key in changes) {
      changed = true;
      render(changes[key].newValue);
    }
  });
  const stored = await chrome.storage.session.get(key);
  if (!changed) render(stored[key]);
}
start().catch(() => {
  byId('feedback').textContent = 'Rouvrez l’assistant depuis le dossier CustomsFlow.';
});
