const localOrigin = 'http://127.0.0.1:8626';
const demo = 'https://issa-diallo.github.io/customsflow-demo/';
const panelUrl = chrome.runtime.getURL('panel.html');
const eligible = new Set(['work', 'extra', 'ready']);
const queues = new Map();
const keyFor = windowId => 'window-' + windowId;

function sourceOrigin(value) {
  try {
    const url = new URL(value);
    const page = url.origin + url.pathname;
    if (page === localOrigin + '/maquette.html' || page === demo || page === demo + 'index.html') return url.origin;
  } catch {
    return null;
  }
  return null;
}

// A decision about a pending case must not race with navigation, another click or closing its source.
function update(windowId, mutate) {
  const previous = queues.get(windowId) || Promise.resolve();
  const key = keyFor(windowId);
  const task = previous.catch(() => {}).then(async () => {
    const state = (await chrome.storage.session.get(key))[key] || { pinned: null, candidate: null };
    const before = JSON.stringify(state);
    await mutate(state);
    if (before !== JSON.stringify(state)) {
      if (state.pinned || state.candidate) await chrome.storage.session.set({ [key]: state });
      else await chrome.storage.session.remove(key);
    }
  });
  queues.set(windowId, task);
  task.finally(() => { if (queues.get(windowId) === task) queues.delete(windowId); }).catch(() => {});
  return task;
}

function checkedCase(raw) {
  const text = value => typeof value === 'string' && value.length <= 4096;
  if (!raw || ![raw.id, raw.buyer, raw.vehicle].every(text) || !raw.id ||
      !['new', 'work', 'extra', 'ready', 'refused'].includes(raw.status)) return null;
  const { id, buyer, vehicle, status } = raw;
  const documents = [];
  if (eligible.has(status)) {
    if (!Array.isArray(raw.documents) || raw.documents.length > 160) return null;
    for (const doc of raw.documents) {
      if (!doc || !text(doc.title) || !Array.isArray(doc.fields) || doc.fields.length > 96) return null;
      const fields = [];
      for (const field of doc.fields) {
        if (!field || !text(field.label) || !text(field.value)) return null;
        if (field.value.trim()) fields.push({ label: field.label, value: field.value });
      }
      documents.push({ title: doc.title, fields });
    }
  }
  return { id, buyer, vehicle, status, documents };
}

function forgetSource(state, tabId) {
  if (state.pinned?.tabId === tabId) state.pinned = null;
  if (state.candidate?.tabId === tabId) state.candidate = null;
}

function observe(state, tab, origin, context, select) {
  if (context?.version !== 1 || !['case','list'].includes(context.view)) {
    forgetSource(state, tab.id);
    return;
  }
  if (context.view === 'list') {
    if (state.candidate?.tabId === tab.id) state.candidate = null;
    return;
  }
  const dossier = checkedCase(context.dossier);
  if (!dossier) {
    forgetSource(state, tab.id);
    return;
  }
  const item = { tabId: tab.id, origin, dossier };
  const sameCase = () => state.pinned?.origin === origin && state.pinned.dossier.id === dossier.id;
  if (sameCase()) {
    // A change to the same case from another source may also revoke it.
    if (!eligible.has(dossier.status)) state.pinned = null;
    else if (state.pinned.tabId === tab.id || tab.active || select) state.pinned = item;
  }
  if (select && eligible.has(dossier.status)) state.pinned = item;
  if (tab.active || select || state.candidate?.tabId === tab.id) {
    if (sameCase() || dossier.status === 'refused') state.candidate = null;
    else {
      const { id, buyer, vehicle, status } = dossier;
      state.candidate = { tabId: tab.id, origin, dossier: { id, buyer, vehicle, status } };
    }
  }
}

async function choose(windowId, id, origin, take) {
  await update(windowId, async state => {
    const candidate = state.candidate;
    if (!candidate || candidate.dossier.id !== id || candidate.origin !== origin) throw new Error('La sélection a changé.');
    const tab = await chrome.tabs.get(candidate.tabId);
    if (tab.windowId !== windowId) throw new Error('Le dossier a changé de fenêtre.');
    const context = await chrome.tabs.sendMessage(tab.id, { type: 'read-case', id, origin, take }, { frameId: 0 });
    if (context?.dossier?.id !== id || !eligible.has(context.dossier.status)) {
      throw new Error('Rouvrez le dossier dans CustomsFlow.');
    }
    observe(state, tab, origin, context, true);
  });
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || !message) return;
  const tab = sender.tab;
  const origin = sourceOrigin(sender.url);
  let work;
  if (tab && sender.frameId === 0 && origin && ['open', 'toolbar', 'context'].includes(message.type)) {
    // Open synchronously on the gesture, before storage or tab operations.
    const open = message.type === 'open';
    const opened = open ? chrome.sidePanel.open({ windowId: tab.windowId }) : Promise.resolve();
    work = Promise.all([opened, update(tab.windowId, state => {
      const select = open || (message.type === 'toolbar' && !state.pinned);
      observe(state, tab, origin, message.context, select);
    })]);
  } else if (sender.url === panelUrl && message.type === 'choose' && Number.isInteger(message.windowId)) {
    work = choose(message.windowId, message.id, message.origin ?? localOrigin, message.take === true);
  } else return;
  work.then(() => respond({ ok: true }), () => respond({ ok: false }));
  return true;
});

chrome.action.onClicked.addListener(tab => {
  chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
  // Only our narrowly scoped content script can answer. The active business tab is never inspected.
  chrome.tabs.sendMessage(tab.id, { type: 'show-case' }, { frameId: 0 }).catch(() => {});
});

chrome.tabs.onRemoved.addListener((id, info) => {
  update(info.windowId, state => forgetSource(state, id)).catch(() => {});
});
chrome.tabs.onDetached.addListener((id, info) => {
  update(info.oldWindowId, state => forgetSource(state, id)).catch(() => {});
});
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (change.status === 'loading') update(tab.windowId, state => forgetSource(state, id)).catch(() => {});
});
chrome.windows.onRemoved.addListener(id => {
  update(id, state => { state.pinned = null; state.candidate = null; }).catch(() => {});
});
