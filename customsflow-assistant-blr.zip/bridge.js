(() => {
  const allowedPages = new Set([
    'http://127.0.0.1:8626/maquette.html',
    'https://issa-diallo.github.io/customsflow-demo/',
    'https://issa-diallo.github.io/customsflow-demo/index.html'
  ]);
  const isDemoPage = () => window === window.top && allowedPages.has(location.origin + location.pathname);
  if (!isDemoPage()) return;

  function snapshot() {
    try {
      return JSON.parse(document.getElementById('cf-assistant-context').textContent);
    } catch {
      return { version: 1, view: 'outside' };
    }
  }

  function publish(type = 'context') {
    if (isDemoPage()) chrome.runtime.sendMessage({ type, context: snapshot() }).catch(() => {});
  }

  document.addEventListener('cf-assistant-update', () => publish());
  document.addEventListener('visibilitychange', () => { if (!document.hidden) publish(); });
  window.addEventListener('pageshow', () => publish());

  document.addEventListener('click', event => {
    if (event.isTrusted && event.target.closest('[data-cf-assistant="take"],[data-cf-assistant="open"]')) {
      publish('open');
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !isDemoPage()) return;
    if (message.type === 'show-case') {
      publish('toolbar');
      respond({ ok: true });
      return;
    }
    if (message.type !== 'read-case' || message.origin !== location.origin) return;
    const context = snapshot();
    if (message.id && context.dossier?.id !== message.id) {
      respond(null);
      return;
    }
    if (message.take && context.dossier?.status === 'new') {
      document.querySelector('[data-cf-assistant="take"]')?.click();
    }
    respond(snapshot());
  });

  document.documentElement.dataset.cfAssistant = 'ready';
  document.dispatchEvent(new Event('cf-assistant-ready'));
  publish();
})();
